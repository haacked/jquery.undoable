See http://haacked.com/archive/2010/01/01/jquery-undoable-plugin.aspx for more details

This is a plugin that provides a more usable alternative to confirmation dialogs by 
assisting in building user interfaces which allow undoing operations.

To see the plugin in action, visit http://demo.haacked.com/jquery.undoable/